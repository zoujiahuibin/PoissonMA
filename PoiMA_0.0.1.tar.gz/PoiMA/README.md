
# PoiMA

<!-- badges: start -->
<!-- badges: end -->

Model averaging is a popular methodology to promote prediction and deal with the uncertainty of covariate choice when we use a statistical model. PoiMA is designed to implement model averaging for Poisson regressions, in which the criterion to calculate model-averaging weight is unbiased.


## Installation

You can install the development version of PoiMA from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("zoujiahuibin/PoissonMA")
```

## Example

There are two a basic examples which show you how to solve a common problem:

``` r
# Exapmle 1
library(PoiMA)
beta0=rep(0.5,5)
X=rmvnorm(100,mean=rep(0,5))
lambda=exp(X%*%beta0)
y=rpois(100,lambda)
PoissonMA(y,X, modeltype='nested',intercept=FALSE)
```
```r
library(PoiMA)
beta0=rep(0.5,5)
X=cbind(1,rmvnorm(100,mean=rep(0,4)))
lambda=exp(X%*%beta0)
y=rpois(100,lambda)
PoissonMA(y,X, modeltype='nested',intercept=TRUE)
```

